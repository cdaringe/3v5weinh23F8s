# welcome to the cosmos

Cadet #{cosmonautId}, welcome to the space program.

You will be deployed in {days} days on shuttle "{shuttleName}"!
