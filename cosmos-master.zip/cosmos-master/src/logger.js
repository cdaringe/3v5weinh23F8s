module.exports = (...args) => console.log('[cosmos]', ...args)
